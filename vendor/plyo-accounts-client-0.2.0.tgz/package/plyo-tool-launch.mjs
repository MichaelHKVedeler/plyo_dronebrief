const storageKey = 'plyo-renderflow-connection';
const hex = /^[a-f0-9]{64}$/;
const failure = () => new Error('This connection expired or is invalid. Open the tool from Toolkits again.');
const random = () => Array.from(crypto.getRandomValues(new Uint8Array(32)), value => value.toString(16).padStart(2, '0')).join('');

export function hasToolLaunch(location) {
  return new URLSearchParams(location.search).has('plyo-connect') || new URLSearchParams(location.hash.slice(1)).has('plyo-code');
}

function launchAccount(query, callback) {
  const account = query.get('account');
  if (query.get('plyo-connect') !== '1' || query.size !== (account ? 2 : 1) || callback.size ||
      (query.has('account') && (!account || account.length > 128))) throw failure();
  return account;
}

export function canResumeToolSession(location, user) {
  const query = new URLSearchParams(location.search);
  if (!query.has('plyo-connect')) return false;
  const account = launchAccount(query, new URLSearchParams(location.hash.slice(1)));
  // The account hint selects a saved identity; the server still checks its token and current permission.
  return !!account && user?.uid === account;
}

export async function continueToolLaunch(accountsOrigin, endpoint, signal, tool = 'renderflow') {
  const query = new URLSearchParams(location.search), callback = new URLSearchParams(location.hash.slice(1));
  // Clear the temporary code before loading the board or making any network requests.
  history.replaceState(null, '', location.pathname);
  if (query.has('plyo-connect')) {
    launchAccount(query, callback);
    const state = random(), verifier = random();
    const hash = new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(verifier)));
    const challenge = btoa(String.fromCharCode(...hash)).replaceAll('+', '-').replaceAll('/', '_').replace(/=+$/, '');
    signal.throwIfAborted();
    sessionStorage.setItem(storageKey, JSON.stringify({state, verifier, createdAt: Date.now()}));
    location.replace(`${accountsOrigin}/?connect=${tool}&state=${state}&challenge=${challenge}`);
    return null;
  }
  const saved = sessionStorage.getItem(storageKey);
  sessionStorage.removeItem(storageKey);
  let pending;
  try {pending = JSON.parse(saved);} catch {throw failure();}
  const code = callback.get('plyo-code'), state = callback.get('state');
  if (query.size || callback.size !== 2 || !/^[A-Za-z0-9_-]{43}$/.test(code || '') || !hex.test(state || '') ||
      !pending || pending.state !== state || typeof pending.verifier !== 'string' || !hex.test(pending.verifier) || !Number.isFinite(pending.createdAt) ||
      Date.now() - pending.createdAt < 0 || Date.now() - pending.createdAt > 600000) throw failure();
  signal.throwIfAborted();
  const response = await fetch(endpoint, {
    method: 'POST', headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({tool, code, verifier: pending.verifier}),
    signal: AbortSignal.any([signal, AbortSignal.timeout(40000)]), credentials: 'omit', cache: 'no-store',
  });
  const data = await response.json();
  if (!response.ok || typeof data.customToken !== 'string' || data.customToken.length < 100 || data.customToken.length > 20000) throw new Error(data.error || 'The connection could not be completed.');
  return data.customToken;
}
