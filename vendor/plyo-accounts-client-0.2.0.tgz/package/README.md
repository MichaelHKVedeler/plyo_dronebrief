# Plyo Accounts client

Small versioned helpers for independent Plyo applications. This package contains
no tool application, Firebase configuration, credentials, or permission records.
The server and each tool's database rules remain responsible for access control.

- `@plyo/accounts-client/connection`: validated popup exchange.
- `@plyo/accounts-client/tool-launch`: the same-tab PKCE handoff from Toolkits. The
  tool ID is the last argument and defaults to `renderflow`.
- `@plyo/accounts-client/loading`: navigation loading state.
- `@plyo/accounts-client/vite`: the shared initial loading screen.

Run the package tests through the Toolkits root `npm run test:unit`.
Use `npm pack` in this directory to create `plyo-accounts-client-0.2.0.tgz`.
RenderFlow (`firebase-board/vendor/`, still on 0.1.1) and Dronebrief (`vendor/`)
commit that exact package and pin it in their lockfiles, so building them needs
neither a sibling checkout nor private package-registry credentials. Package changes require a version bump, a new
archive, and a tested dependency update in each consuming repository.

Toolkits uses the package source within its own repository. Keep the protocol
backward compatible while independently deployed consumers upgrade.
