import {readFileSync} from 'node:fs';

export function plyoLoadingScreen() {
  const css = readFileSync(new URL('./plyo-tool-loading.css', import.meta.url), 'utf8');
  return {
    name: 'plyo-loading-screen',
    transformIndexHtml: {order: 'post', handler(html) {
      return {
        html: html.replace('<html', '<html data-plyo-loading'),
        tags: [
          {tag: 'style', children: css, injectTo: 'head-prepend'},
          {tag: 'div', attrs: {id: 'plyo-loading', role: 'status', 'aria-live': 'polite', 'aria-busy': 'true'},
            children: '<strong>plyo</strong><span>Loading…</span>', injectTo: 'body-prepend'},
        ],
      };
    }},
  };
}
