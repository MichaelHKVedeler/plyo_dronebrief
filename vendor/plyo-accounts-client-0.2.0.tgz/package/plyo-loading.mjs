export function setPageLoading(loading) {
  document.documentElement.toggleAttribute('data-plyo-loading', loading);
}

export function showNavigationLoading(event) {
  if (event.defaultPrevented || event.button !== 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
  setPageLoading(true);
}

// A restored page must recheck access instead of retaining its departure overlay or showing stale content.
window.addEventListener('pageshow', event => {if (event.persisted) {setPageLoading(true); location.reload();}});
