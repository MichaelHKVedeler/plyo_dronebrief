export function acceptsReply(event, {origin, popup, state}) {
  return !!popup && event.origin === origin && event.source === popup && event.data?.type === 'plyo-shared-login' &&
    event.data.state === state && typeof event.data.customToken === 'string' && event.data.customToken.length >= 100 && event.data.customToken.length <= 20000;
}

export function requestConnection(accountsOrigin, tool = 'shared-login-test') {
  if (!['shared-login-test', 'renderflow'].includes(tool)) throw new Error('This tool is not registered.');
  const state = Array.from(crypto.getRandomValues(new Uint8Array(32)), value => value.toString(16).padStart(2, '0')).join('');
  const url = new URL('/', accountsOrigin);
  url.searchParams.set('connect', tool);
  url.searchParams.set('state', state);
  const popup = window.open(url, `plyo-${state}`, 'popup,width=560,height=760');
  if (!popup) return Promise.reject(new Error('Allow popups for this site, then try again.'));
  return new Promise((resolve, reject) => {
    const cleanup = () => {clearInterval(closed); clearTimeout(timeout); window.removeEventListener('message', receive); if (!popup.closed) popup.close();};
    const receive = event => {
      if (!acceptsReply(event, {origin: accountsOrigin, popup, state})) return;
      cleanup(); resolve(event.data.customToken);
    };
    const closed = setInterval(() => {
      if (popup.closed) {cleanup(); reject(new Error('The sign-in window was closed. Try again when you’re ready.'));}
    }, 500);
    const timeout = setTimeout(() => {cleanup(); reject(new Error('Sign-in timed out. Please try again.'));}, 180000);
    window.addEventListener('message', receive);
  });
}
