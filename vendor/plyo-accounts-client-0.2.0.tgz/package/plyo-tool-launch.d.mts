type Place = Pick<Location, 'search' | 'hash'>;
export function hasToolLaunch(location: Place): boolean;
export function canResumeToolSession(location: Place, user: {uid: string} | null | undefined): boolean;
/** Resolves to a custom token after the callback, or null while redirecting to Accounts. */
export function continueToolLaunch(accountsOrigin: string, endpoint: string, signal: AbortSignal, tool?: string): Promise<string | null>;
